using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.IO;
using System.Xml;
using System.Xml.XPath;

namespace XMLSchemaGenerator
{
	/// <summary>
	/// XMLSchemaGenerator
	/// 
	/// A small tool that generates the schema
	/// for an XML fragment. Helpful for generating
	/// a schema from the MSDN documentation.
	/// 
	/// </summary>
	/// <remarks>
	/// Copyright (c) Ross Donald - Rad Software
	/// mailto:ross@radsoftware.com.au
	/// http://www.radsoftware.com.au
	/// </remarks>
	public class MainForm : System.Windows.Forms.Form
	{
		

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		private System.Windows.Forms.TextBox ctlInput;
		private System.Windows.Forms.Button btnGO;
		private System.Windows.Forms.TabControl ctlTab;
		private System.Windows.Forms.TabPage ctlInputTabPage;
		private System.Windows.Forms.TabPage ctlOutputTabPage;
		private System.Windows.Forms.TextBox ctlOutput;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnDefault;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.ctlInput = new System.Windows.Forms.TextBox();
			this.btnGO = new System.Windows.Forms.Button();
			this.ctlTab = new System.Windows.Forms.TabControl();
			this.ctlInputTabPage = new System.Windows.Forms.TabPage();
			this.label1 = new System.Windows.Forms.Label();
			this.ctlOutputTabPage = new System.Windows.Forms.TabPage();
			this.ctlOutput = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnDefault = new System.Windows.Forms.Button();
			this.ctlTab.SuspendLayout();
			this.ctlInputTabPage.SuspendLayout();
			this.ctlOutputTabPage.SuspendLayout();
			this.SuspendLayout();
			// 
			// ctlInput
			// 
			this.ctlInput.AcceptsReturn = true;
			this.ctlInput.AcceptsTab = true;
			this.ctlInput.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ctlInput.Font = new System.Drawing.Font("Lucida Console", 9.75F);
			this.ctlInput.Location = new System.Drawing.Point(0, 23);
			this.ctlInput.Multiline = true;
			this.ctlInput.Name = "ctlInput";
			this.ctlInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.ctlInput.Size = new System.Drawing.Size(856, 498);
			this.ctlInput.TabIndex = 0;
			this.ctlInput.Text = "";
			this.ctlInput.WordWrap = false;
			// 
			// btnGO
			// 
			this.btnGO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnGO.Location = new System.Drawing.Point(784, 560);
			this.btnGO.Name = "btnGO";
			this.btnGO.TabIndex = 1;
			this.btnGO.Text = "GO";
			this.btnGO.Click += new System.EventHandler(this.btnGO_Click);
			// 
			// ctlTab
			// 
			this.ctlTab.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.ctlTab.Controls.Add(this.ctlInputTabPage);
			this.ctlTab.Controls.Add(this.ctlOutputTabPage);
			this.ctlTab.Location = new System.Drawing.Point(4, 4);
			this.ctlTab.Name = "ctlTab";
			this.ctlTab.SelectedIndex = 0;
			this.ctlTab.Size = new System.Drawing.Size(864, 548);
			this.ctlTab.TabIndex = 2;
			// 
			// ctlInputTabPage
			// 
			this.ctlInputTabPage.Controls.Add(this.ctlInput);
			this.ctlInputTabPage.Controls.Add(this.label1);
			this.ctlInputTabPage.Location = new System.Drawing.Point(4, 23);
			this.ctlInputTabPage.Name = "ctlInputTabPage";
			this.ctlInputTabPage.Size = new System.Drawing.Size(856, 521);
			this.ctlInputTabPage.TabIndex = 0;
			this.ctlInputTabPage.Text = "Input XML";
			// 
			// label1
			// 
			this.label1.Dock = System.Windows.Forms.DockStyle.Top;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(856, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Enter an XML fragment.";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ctlOutputTabPage
			// 
			this.ctlOutputTabPage.Controls.Add(this.ctlOutput);
			this.ctlOutputTabPage.Controls.Add(this.label2);
			this.ctlOutputTabPage.Location = new System.Drawing.Point(4, 23);
			this.ctlOutputTabPage.Name = "ctlOutputTabPage";
			this.ctlOutputTabPage.Size = new System.Drawing.Size(856, 521);
			this.ctlOutputTabPage.TabIndex = 1;
			this.ctlOutputTabPage.Text = "Output XSD";
			// 
			// ctlOutput
			// 
			this.ctlOutput.AcceptsReturn = true;
			this.ctlOutput.AcceptsTab = true;
			this.ctlOutput.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ctlOutput.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ctlOutput.Location = new System.Drawing.Point(0, 23);
			this.ctlOutput.Multiline = true;
			this.ctlOutput.Name = "ctlOutput";
			this.ctlOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.ctlOutput.Size = new System.Drawing.Size(856, 498);
			this.ctlOutput.TabIndex = 0;
			this.ctlOutput.Text = "";
			this.ctlOutput.WordWrap = false;
			// 
			// label2
			// 
			this.label2.Dock = System.Windows.Forms.DockStyle.Top;
			this.label2.Location = new System.Drawing.Point(0, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(856, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "This is a Schema definition for the XML fragment.";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnDefault
			// 
			this.btnDefault.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnDefault.Location = new System.Drawing.Point(8, 560);
			this.btnDefault.Name = "btnDefault";
			this.btnDefault.TabIndex = 3;
			this.btnDefault.Text = "Default";
			this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
			// 
			// MainForm
			// 
			this.AcceptButton = this.btnGO;
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 15);
			this.ClientSize = new System.Drawing.Size(872, 594);
			this.Controls.Add(this.btnDefault);
			this.Controls.Add(this.ctlTab);
			this.Controls.Add(this.btnGO);
			this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "XML Schema Generator - www.radsoftware.com.au";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ctlTab.ResumeLayout(false);
			this.ctlInputTabPage.ResumeLayout(false);
			this.ctlOutputTabPage.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void btnGO_Click(object sender, System.EventArgs e)
		{
			try
			{
				XmlDocument XmlInput = new XmlDocument();

				StringWriter SchemaStringWriter = new StringWriter();
				XmlTextWriter writer = new XmlTextWriter(SchemaStringWriter);
				writer.Formatting = Formatting.Indented;

				XmlInput.LoadXml(ctlInput.Text);

				ProcessNode(XmlInput.DocumentElement, writer);

				ctlOutput.Text = SchemaStringWriter.ToString();

				ctlTab.SelectedTab = ctlTab.TabPages[1];
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void ProcessNode(XmlNode nodeCurrent, XmlTextWriter writer)
		{
			//writer.WriteComment(nodeCurrent.Name);
		
			writer.WriteStartElement("xs:element");
			writer.WriteAttributeString("name", nodeCurrent.Name);
			writer.WriteAttributeString("minOccurs", "0");

			writer.WriteStartElement("xs:complexType");

			//
			// Recursively process child nodes
			//
			XmlNodeList ChildNodes = nodeCurrent.SelectNodes("child::*");

			if (ChildNodes.Count > 0)
			{
				writer.WriteStartElement("xs:choice");
			}

			foreach (XmlNode ChildNodeCurrent in ChildNodes)
			{
				ProcessNode(ChildNodeCurrent, writer);
			}
	
			if (ChildNodes.Count > 0)
			{
				writer.WriteEndElement();
			}
		
			XmlNodeList ChildAttributes = nodeCurrent.SelectNodes("attribute::*");

			foreach (XmlNode AttributeNode in ChildAttributes)
			{
				writer.WriteStartElement("xs:attribute");
				writer.WriteAttributeString("name", AttributeNode.Name);

				//
				// If the attribute value contains the pipe ("true|false")
				// then create an enumeration
				//
				if (AttributeNode.Value.IndexOf('|') > -1)
				{
					string[] EnumValue = AttributeNode.Value.Split('|');
		
					writer.WriteStartElement("xs:simpleType");
					writer.WriteStartElement("xs:restriction");
					writer.WriteAttributeString("base", "xs:string");

					for (int i=0; i <= EnumValue.GetUpperBound(0); i++)
					{
						writer.WriteStartElement("xs:enumeration");
						writer.WriteAttributeString("value", EnumValue[i].ToString().Trim());
						writer.WriteEndElement();
					}

					writer.WriteEndElement(); //restriction
					writer.WriteEndElement(); //simpleType
				}
				else
				{
					writer.WriteAttributeString("type", "xs:string");
				}

				writer.WriteEndElement();
			}


			writer.WriteEndElement(); // complexType
			writer.WriteEndElement(); // element
		}

		private void btnDefault_Click(object sender, System.EventArgs e)
		{
			//
			// An example to demonstrate how this tool works
			//
			ctlInput.Text = @"<authentication mode=""Windows|Forms|Passport|None"">
   <forms name=""name""
          loginUrl=""url"" 
          protection=""All|None|Encryption|Validation""
          timeout=""30"" path=""/"" >
          requireSSL=""true|false""
          slidingExpiration=""true|false"">
      <credentials passwordFormat=""Clear|SHA1|MD5"">
         <user name=""username"" password=""password""/>
      </credentials>
   </forms>
   <passport redirectUrl=""internal""/>
</authentication>";

			ctlOutput.Text = string.Empty;
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			btnDefault_Click(this, new EventArgs());
		}
	}
}
